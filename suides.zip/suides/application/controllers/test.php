<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Description of test
 *
 * @author teukapmaths
 */
class Test extends CI_Controller {
    //put your code here
    public function go() {
        $eleve = new Eleve();

        $eleve->nom = "TEGANTCHOUANG TEUKAP GAËL BORIS";
        $eleve->sexe = "M";
        $eleve->datenaissance = "1993-07-17";
        $eleve->lieunaissance = "BAFOUSSAM";
        $eleve->langue = "FR";
        $eleve->email = "teukapmaths@gmail.com";
        $eleve->tel = "695916933";

        $result = $eleve->save();

        echo 'resultat : ' . $result;
    }
}
