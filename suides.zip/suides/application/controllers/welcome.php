<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    /**
     * @category Libraries
     * @package  CodeIgniter 3.0
     * @author   Yp <purwantoyudi42@gmail.com>
     * @link     https://timexstudio.com
     * @license  Protected
     */
    public function index() {
        $this->load->library('twig');
        $this->twig->add_function('base_url');
        $data['title'] = "Welcome to CodeIgniter";
        $data['head'] = "Welcome to CodeIgniter!";
        $data['content'] = "The page you are looking at is being generated dynamically by CodeIgniter and template engine Twig.";
        $this->twig->display('view', $data);
        // $this->load->view('welcome_message');
    }

    public function elegant() {
        $users = User::all();
        $i = 1;
        foreach ($users as $user) {
            echo "$i. " . $user->login . " " . $user->passwd . " " . $user->description . " " . $user->role . "<br />";
            $i++;
        }
    }

    public function easy() {
        //use library easy parse
        $this->load->library('easy_parser');
        $q = $this->db->get('utilisateur');
        $data = array(
            'title' => "Welcome to CodeIgniter",
            'head' => "Welcome to CodeIgniter!",
            'content' => $q->result()
        );
        //this use easy parse
        //$this->easy_parser->parse('index', $data);
        echo json_encode($data);
    }

    public function get() {
        //Updating Retrieved Model
        $user = User::find('tgb17');
        $user->role = "proviseur";
        $user->save();
        
        /*
         User::all( array('id', 'username') );
         User::where('status', 1)->get( array('id', 'username') );
         User::select( array('id', 'username') )->get();
         User::where('status', 1)->first( array('id', 'username') );
        */

        //$users = User::find('tgb17', 't_hybrid');
        $users = User::where('role', 'enseignant')->get(array('login', 'description'));
        foreach ($users as $user) {
            echo $user->login . " | " . $user->description . "<br />";
        }

        $total = User::count();
        echo "User's total : " . $total;

        //$max = Product::max('price');

        // Example of chaining with where()
        //$min = Product::where('category', 1)->min('price');

        //$avg = Product::avg('price');

        // Another chaining example
        //$sum = Order::where('status', 1)->sum('price');

        // Creating A New Model
        $user =  new User;

        $user->login = 'toto';
        $user->passwd = sha1("toto");
        $user->description = "TOTO JEAN";
        $user->codeetablissement = "LYCLABAF";
        $user->role = "eleve";

        // if your model uses auto increment primary key,
        // the generated insert id will be set to the object : $user->id
        $user->save();

        echo '<br />***************************************<br />';
        
        $users = User::where('role', 'surveillant')->get(array('login', 'description'));
        foreach ($users as $user) {
            echo $user->login . " | " . $user->description . "<br />";
        }

        $total = User::count();
        echo "User's total : " . $total;
    }

    public function update() {
        User::where('login', 'toto')->update(array('passwd' => "toto"));
        $user = User::find('toto');
        echo $user->login . ' ' . $user->passwd . ' ' . $user->description . " " . $user->role;
    }

    public function delete() {
        if(User::delete('toto')) {
            echo "Toto supprimé !";
        } else {
            echo "Echec suppression toto !";
        }
    }

    public function active() {
        $users = User::active()->get();
        foreach ($users as $user) {
            echo $user->login . " | " . $user->description . "<br />";
        }
    }

    public function search($q) {
        $users = User::search($q)->get();
        foreach ($users as $user) {
            echo $user->login . " | " . $user->description . "<br />";
        }
    }

    public function phone() {
        $user = User::find('tgb17');
        $phone = $user->phone;
        // You can work with $phone object like the usual way

        // Returns its property
        echo "Owner : " . $user->description . "<br />";
        echo "Phone's infos : " . $phone->brand . " " . $phone->price . " FCFA";
    }

    public function generate() {
        //echo getcwd();
        $json = file_get_contents("files/relationship.json");
        $relationship = json_decode($json, true);
        
        foreach ($relationship as $table => $relations) {
            $handle = fopen("application/models/".$table.".php", "w");
            
            $code = "<?php 
                        use Elegant\Model as Timex;
                        class ". $table . " extends Timex {
                            protected \$table = '$table';";

            if(array_key_exists("hasOne", $relations)) {

                foreach ($relations['hasOne']['table'] as $value) {
                    $code .= "function ".$value."() {
                                return \$this->hasOne('$value', '".$relations['hasOne']['fk']."');
                              }";
                }
                
            }
            if(array_key_exists("hasMany", $relations)) {

                foreach ($relations['hasMany']['table'] as $value) {
                    $code .= "function ".$value."() {
                                return \$this->hasMany('$value', '".$relations['hasMany']['fk']."');
                              }";
                }

            }
            if(array_key_exists("belongsToMany", $relations)) {
                $i = -1;
                foreach ($relations['belongsToMany']['table'] as $value) {
                    $code .= "function ".$value."() {
                                return \$this->belongsToMany('$value', '". $relations['belongsToMany']['pivotTable'][++$i] ."', '".$table.$relations['belongsToMany']['suffix']."', '".$value.$relations['belongsToMany']['suffix']."');
                              }";
                }

            }
            if(array_key_exists("belongsTo", $relations)) {

                foreach ($relations['belongsTo']['table'] as $value) {
                    $code .= "function ".$value."() {
                                return \$this->belongsTo('$value', '".$value.$relations['belongsTo']['suffix']."');
                              }";
                }

            }
            if(empty($relations)) {
                echo "<br />"."$table"."<br />";
            }

            $code .= "}?>";

            // Génération du code des classes avec leurs différentes relations
            fwrite($handle, $code);
            fclose($handle);
        }

        echo "<br /> ************ Génération terminée ! ************* <br />";
    }
}
