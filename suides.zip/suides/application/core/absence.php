<?php

/**
 * @access public
 * @author teukapmaths
 * @package suides.gestion
 */
class absence {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AttributeType int
     */
    private $nombre;

    /**
     * @AttributeType String
     */
    private $date;

    /**
     * @AttributeType int
     */
    private $annee;

    function getId() {
        return $this->id;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getDate() {
        return $this->date;
    }

    function getAnnee() {
        return $this->annee;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setDate($date) {
        $this->date = $date;
    }

    function setAnnee($annee) {
        $this->annee = $annee;
    }
}

