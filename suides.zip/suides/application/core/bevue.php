<?php

/**
 * @access public
 * @author teukapmaths
 * @package suides.gestion
 */
class Bevue {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AttributeType String
     */
    private $motif;

    /**
     * @AttributeType String
     */
    private $date;

    /**
     * @AttributeType String
     */
    private $commentaire;

    /**
     * @AttributeType int
     */
    private $annee;

    function getId() {
        return $this->id;
    }

    function getMotif() {
        return $this->motif;
    }

    function getDate() {
        return $this->date;
    }

    function getCommentaire() {
        return $this->commentaire;
    }

    function getAnnee() {
        return $this->annee;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setMotif($motif) {
        $this->motif = $motif;
    }

    function setDate($date) {
        $this->date = $date;
    }

    function setCommentaire($commentaire) {
        $this->commentaire = $commentaire;
    }

    function setAnnee($annee) {
        $this->annee = $annee;
    }


}

