<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Classe {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AttributeType String
     */
    private $commentaire;

    /**
     * @AttributeType String
     */
    private $annee;

    /**
     * @AssociationType core.programme
     */
    public $programme;

    /**
     * @AssociationType core.eleve
     * @AssociationMultiplicity 1..*
     */
    public $eleve = array();

    /**
     * @access public
     */
    public function getMyPupils() {
        // Not yet implemented
    }

    /**
     * @access public
     */
    public function getMySurveillant() {
        // Not yet implemented
    }

    function getId() {
        return $this->id;
    }

    function getCommentaire() {
        return $this->commentaire;
    }

    function getAnnee() {
        return $this->annee;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setCommentaire($commentaire) {
        $this->commentaire = $commentaire;
    }

    function setAnnee($annee) {
        $this->annee = $annee;
    }
}

