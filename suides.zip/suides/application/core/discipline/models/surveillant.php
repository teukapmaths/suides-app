<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Surveillant extends User implements AgentSurveille {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AssociationType core.classe
     * @AssociationMultiplicity 1..*
     */
    public $classe = array();

    /**
     * @access public
     */
    public function getMyClasses() {
        // Not yet implemented
    }

    /**
     * donne la possibilit� � un surveillant, ici principal, de pointer les heures d'absence d'un �l�ve suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param core.Absence absence
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType absence core.Absence
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function addHour(Absence $absence, Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * donne la possibilit� � un surveillant, ici principal, de modifier les heures d'absence point�es d'un �l�ve suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param core.Absence absence
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType absence core.Absence
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function modifyHour(Absence $absence, Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * donne la possibilit� � un surveillant, ici principal, de pointer les b�vues d'un �l�ve suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param core.Bevue bevue
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType bevue core.Bevue
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function addGaffe(Bevue $bevue, Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * donne la possibilit� � un surveillant, ici principal, de modifier les b�vues point�es d'un �l�ve suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param core.Bevue bevue
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType bevue core.Bevue
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function modifyGaffe(Bevue $bevue, Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * donne la possibilit� � un surveillant, ici principal, de consulter les heures d'absence d'un �l�ve suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function consultHours(Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * donne la possibilit� � un surveillant, ici principal, de consulter les gaffes d'un �l�ve suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function consultGaffes(Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param core.Absence absence
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType absence core.Absence
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function deleteHour(Absence $absence, Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param core.Bevue bevue
     * @param core.Eleve eleve
     * @param core.Evaluation evaluation
     * @param core.Trimestre trimestre
     * @param int annee
     * @ParamType bevue core.Bevue
     * @ParamType eleve core.Eleve
     * @ParamType evaluation core.Evaluation
     * @ParamType trimestre core.Trimestre
     * @ParamType annee int
     */
    public function deleteGaffe(Bevue $bevue, Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

}

?>