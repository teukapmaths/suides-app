<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Eleve extends Person {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AssociationType core.surveillant
     * @AssociationMultiplicity 1
     */
    public $surveillant;

    /**
     * @AssociationType core.classe
     * @AssociationMultiplicity 1..*
     */
    public $unnamed_classe_ = array();

    /**
     * @access public
     */
    public function getMyClass() {
        // Not yet implemented
    }

    /**
     * @access public
     * @param Evaluation evaluation
     * @param Trimestre trimestre
     * @param int annee
     * @ParamType evaluation Evaluation
     * @ParamType trimestre Trimestre
     * @ParamType annee int
     */
    public function getMyGaffes(Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param Evaluation evaluation
     * @param Trimestre trimestre
     * @param int annee
     * @ParamType evaluation Evaluation
     * @ParamType trimestre Trimestre
     * @ParamType annee int
     */
    public function getMyAbsences(Evaluation $evaluation, Trimestre $trimestre, $annee) {
        // Not yet implemented
    }

}

?>