<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Evaluation {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AttributeType String
     */
    private $intitule;

    /**
     * @AttributeType String
     */
    private $commentaire;

    function getId() {
        return $this->id;
    }

    function getIntitule() {
        return $this->intitule;
    }

    function getCommentaire() {
        return $this->commentaire;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setIntitule($intitule) {
        $this->intitule = $intitule;
    }

    function setCommentaire($commentaire) {
        $this->commentaire = $commentaire;
    }


}

