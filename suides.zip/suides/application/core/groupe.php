<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Groupe {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AttributeType String
     */
    private $intitule;

    /**
     * @AttributeType String
     */
    private $description;

    /**
     * @AssociationType core.matiere
     * @AssociationMultiplicity 1..*
     * @AssociationKind Aggregation
     */
    private $matiere = array();

    function getId() {
        return $this->id;
    }

    function getIntitule() {
        return $this->intitule;
    }

    function getDescription() {
        return $this->description;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setIntitule($intitule) {
        $this->intitule = $intitule;
    }

    function setDescription($description) {
        $this->description = $description;
    }

    function getMatiere() {
        return $this->matiere;
    }

    function setMatiere($matiere) {
        $this->matiere = $matiere;
    }

}
