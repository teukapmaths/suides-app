<?php

/**
 * @access public
 * @author teukapmaths
 * @package core.inscription.models
 */
class Econome extends User implements AgentRegistration {

    /**
     * @access public
     * @param Eleve eleve
     * @param Tranche tranche
     * @return Array
     * @ParamType eleve Eleve
     * @ParamType tranche Tranche
     * @ReturnType Array
     */
    public function registerFees(Eleve $eleve, Tranche $tranche) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param Eleve eleve
     * @param Tranche tranche
     * @return Array
     * @ParamType eleve Eleve
     * @ParamType tranche Tranche
     * @ReturnType Array
     */
    public function modifyFees(Eleve $eleve, Tranche $tranche) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param Eleve eleve
     * @param int annee
     * @return Array
     * @ParamType eleve Eleve
     * @ParamType annee int
     * @ReturnType Array
     */
    public function consultFees(Eleve $eleve, $annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param Classe classe
     * @param int annee
     * @return Array
     * @ParamType classe Classe
     * @ParamType annee int
     * @ReturnType Array
     */
    public function consultFeesClass(Classe $classe, $annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param Classe classe
     * @param int annee
     * @ParamType classe Classe
     * @ParamType annee int
     */
    public function printListPupilNotPayFees(Classe $classe, $annee) {
        // Not yet implemented
    }

    /**
     * retourne la liste des �l�ves d'une classe - sp�cifi�e - avec le montant qu'il a d�j� eu � payer pour l'ann�e scolaire en cours ( on peut pr�ciser l'ann�e )
     * @access public
     * @param Classe classe
     * @param int annee
     * @ParamType classe Classe
     * @ParamType annee int
     */
    public function printListPupilsFees(Classe $classe, $annee) {
        // Not yet implemented
    }

}

?>