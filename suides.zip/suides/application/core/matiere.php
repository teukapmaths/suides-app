<?php

/**
 * @access public
 * @author teukapmaths
 * @package suides.gestion
 */
class Matiere {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AttributeType String
     */
    private $intitule;

    /**
     * @AttributeType String
     */
    private $commentaire;

    /**
     * @AssociationType suides.gestion.groupe
     */
    private $groupe;

    /**
     * @AssociationType suides.gestion.programme
     */
    public $programme;

    /**
     * @access public
     */
    public function getEnseignant() {
        // Not yet implemented
    }

    function getId() {
        return $this->id;
    }

    function getIntitule() {
        return $this->intitule;
    }

    function getCommentaire() {
        return $this->commentaire;
    }

    function getGroupe() {
        return $this->groupe;
    }

    function getProgramme() {
        return $this->programme;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setIntitule($intitule) {
        $this->intitule = $intitule;
    }

    function setCommentaire($commentaire) {
        $this->commentaire = $commentaire;
    }

    function setGroupe($groupe) {
        $this->groupe = $groupe;
    }

}

