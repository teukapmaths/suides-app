<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Note {

    /**
     * @AttributeType double
     */
    private $note;

    /**
     * @AttributeType String
     */
    private $appreciation;

    /**
     * @AttributeType String
     */
    private $annee;

    function getNote() {
        return $this->note;
    }

    function getAppreciation() {
        return $this->appreciation;
    }

    function getAnnee() {
        return $this->annee;
    }

    function setNote($note) {
        $this->note = $note;
    }

    function setAppreciation($appreciation) {
        $this->appreciation = $appreciation;
    }

    function setAnnee($annee) {
        $this->annee = $annee;
    }


}

?>