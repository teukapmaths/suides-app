<?php

/**
 * @access public
 * @author teukapmaths
 * @package notes.interfaces
 */
interface AgentEnseigne {

    /**
     * @access public
     * @param suides.gestion.Note note
     * @param suides.gestion.Eleve eleve
     * @param suides.gestion.Matiere matiere
     * @param suides.gestion.Evaluation evaluation
     * @param suides.gestion.Trimestre trimestre
     * @param int annee
     * @ParamType note suides.gestion.Note
     * @ParamType eleve suides.gestion.Eleve
     * @ParamType matiere suides.gestion.Matiere
     * @ParamType evaluation suides.gestion.Evaluation
     * @ParamType trimestre suides.gestion.Trimestre
     * @ParamType annee int
     */
    public function addNote(Note $note, Eleve $eleve, Matiere $matiere, Evaluation $evaluation, Trimestre $trimestre, $annee);

    /**
     * @access public
     * @param suides.gestion.Note note
     * @param suides.gestion.Eleve eleve
     * @param suides.gestion.Matiere matiere
     * @param suides.gestion.Evaluation evaluation
     * @param suides.gestion.Trimestre trimestre
     * @param int annee
     * @ParamType note suides.gestion.Note
     * @ParamType eleve suides.gestion.Eleve
     * @ParamType matiere suides.gestion.Matiere
     * @ParamType evaluation suides.gestion.Evaluation
     * @ParamType trimestre suides.gestion.Trimestre
     * @ParamType annee int
     */
    public function modifyNote(Note $note, Eleve $eleve, Matiere $matiere, Evaluation $evaluation, Trimestre $trimestre, $annee);

    /**
     * Donne la possibilit� de consulter les notes d'une classe, en une mati�re pr�cise comptant pour une s�quence d'un trimestre d'une ann�e acad�mique.
     * @access public
     * @param suides.gestion.Classe classe
     * @param suides.gestion.Matiere matiere
     * @param suides.gestion.Evaluation evaluation
     * @param suides.gestion.Trimestre trimestre
     * @param int annee
     * @ParamType classe suides.gestion.Classe
     * @ParamType matiere suides.gestion.Matiere
     * @ParamType evaluation suides.gestion.Evaluation
     * @ParamType trimestre suides.gestion.Trimestre
     * @ParamType annee int
     */
    public function consultNote(Classe $classe, Matiere $matiere, Evaluation $evaluation, Trimestre $trimestre, $annee);
}
