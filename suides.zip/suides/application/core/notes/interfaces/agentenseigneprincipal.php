<?php

/**
 * @access public
 * @author teukapmaths
 * @package notes.interfaces
 */
interface AgentEnseignePrincipal extends AgentEnseigne {

    /**
     * Donne la possibilit� � un enseignant - principal - de pouvoir imprimer un bulletin d'un �l�ve pour une s�quence - evaluation - d'un trimestre au cours d'une ann�e acad�mique.
     * @access public
     * @param gestion.Eleve eleve
     * @param gestion.Evaluation evaluation
     * @param gestion.Trimestre trimestre
     * @param int annee
     * @ParamType eleve gestion.Eleve
     * @ParamType evaluation gestion.Evaluation
     * @ParamType trimestre gestion.Trimestre
     * @ParamType annee int
     */
    public function printbulletinpupil(Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee);

    /**
     * donne la possibilit� � un enseignant, ici principal, d'imprimer les bulletins d'une classe suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param gestion.Classe classe
     * @param gestion.Evaluation evaluation
     * @param gestion.Trimestre trimestre
     * @param int annee
     * @ParamType classe gestion.Classe
     * @ParamType evaluation gestion.Evaluation
     * @ParamType trimestre gestion.Trimestre
     * @ParamType annee int
     */
    public function printbulletinclass(Classe $classe, Evaluation $evaluation, Trimestre $trimestre, $annee);

    /**
     * donne la possibilit� � un enseignant, ici principal, d'imprimer les bulletins annuel d'une classe suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param gestion.Classe classe
     * @param int annee
     * @ParamType classe gestion.Classe
     * @ParamType annee int
     */
    public function printbulletinannuelclass(Classe $classe, $annee);

    /**
     * donne la possibilit� � un enseignant, ici principal, de visualiser le bulletin d'un �l�ve suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param gestion.Eleve eleve
     * @param gestion.Evaluation evaluation
     * @param gestion.Trimestre trimestre
     * @param int annee
     * @ParamType eleve gestion.Eleve
     * @ParamType evaluation gestion.Evaluation
     * @ParamType trimestre gestion.Trimestre
     * @ParamType annee int
     */
    public function overviewbulletin(Eleve $eleve, Evaluation $evaluation, Trimestre $trimestre, $annee);

    /**
     * donne la possibilit� � un enseignant, ici principal, d'imprimer le bulletin annuel d'une classe suivant les param�tres tels que l'�valuation, le trimestre et l'ann�e scolaire.
     * @access public
     * @param gestion.Eleve eleve
     * @param int annee
     * @ParamType eleve gestion.Eleve
     * @ParamType annee int
     */
    public function printbulletinannuelpupil(Eleve $eleve, $annee);
}
