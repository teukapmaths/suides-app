<?php
/**
 * @access public
 * @author teukapmaths
 * @package notes.models
 */
class AEnseignant extends Enseignant implements AgentEnseigne {
    public function addNote(\Note $note, \Eleve $eleve, \Matiere $matiere, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

    public function consultNote(\Classe $classe, \Matiere $matiere, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

    public function modifyNote(\Note $note, \Eleve $eleve, \Matiere $matiere, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }
}
?>