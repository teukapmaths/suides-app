<?php
/**
 * @access public
 * @author teukapmaths
 * @package notes.models
 */
class APEnseignant extends Enseignant implements AgentEnseignePrincipal {
    public function addNote(\Note $note, \Eleve $eleve, \Matiere $matiere, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

    public function consultNote(\Classe $classe, \Matiere $matiere, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

    public function modifyNote(\Note $note, \Eleve $eleve, \Matiere $matiere, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

    public function overviewbulletin(\Eleve $eleve, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

    public function printbulletinannuelclass(\Classe $classe, $annee) {
        
    }

    public function printbulletinannuelpupil(\Eleve $eleve, $annee) {
        
    }

    public function printbulletinclass(\Classe $classe, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

    public function printbulletinpupil(\Eleve $eleve, \Evaluation $evaluation, \Trimestre $trimestre, $annee) {
        
    }

}
?>