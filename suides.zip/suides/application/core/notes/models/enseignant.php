<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Enseignant extends User {

    /**
     * @AttributeType int
     */
    private $id;

    /**
     * @AssociationType core.programme
     */
    public $enseigner;

    /**
     * @access public
     */
    public function getMyClasses() {
        // Not yet implemented
    }

    /**
     * @access public
     * @param Classe classe
     * @param int annee
     * @ParamType classe Classe
     * @ParamType annee int
     */
    public function getMyMatieres(Classe $classe = NULL, $annee) {
        // Not yet implemented
    }

}

?>