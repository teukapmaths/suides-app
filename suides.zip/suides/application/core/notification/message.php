<?php
/**
 * @access public
 * @author teukapmaths
 * @package suides.gestion.notification
 */
class message {
	/**
	 * @AttributeType String
	 */
	private $libelle;
	/**
	 * @AttributeType String
	 */
	private $tel;
	/**
	 * @AttributeType int
	 */
	private $code;
}
?>