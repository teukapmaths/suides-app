<?php
/**
 * @access public
 * @author teukapmaths
 * @package suides.gestion.notification
 */
class AgentNotification implements INotification {
    /**
     * @access public
     * @param Message message
     * @param Parents parents
     * @ParamType message Message
     * @ParamType parents Parents
     */
    public function send(Message $message, Parents $parents) {
            // Not yet implemented
    }
}
?>