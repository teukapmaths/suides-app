<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Person {

    /**
     * @AttributeType String
     */
    private $nom;

    /**
     * @AttributeType String
     */
    private $sexe;

    /**
     * @AttributeType String
     */
    private $attribute;

    /**
     * @AttributeType String
     */
    private $datenaissance;

    /**
     * @AttributeType String
     */
    private $lieunaissance;

    /**
     * @AttributeType String
     */
    private $email;

    /**
     * @AttributeType String
     */
    private $langue;

    /**
     * @AttributeType String
     */
    private $tel;

}

?>