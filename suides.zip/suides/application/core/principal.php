<?php

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Principal extends User {

    /**
     * @AssociationType core.Classe
     * @AssociationKind Composition
     */
    public $classe;

    /**
     * @access public
     * @param int annee
     * @ParamType annee int
     */
    public function getPercentSuccessByClass($annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param int annee
     * @ParamType annee int
     */
    public function getPercentFailureByClass($annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param int annee
     * @ParamType annee int
     */
    public function getPercentSuccessByClassBySex($annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param int annee
     * @ParamType annee int
     */
    public function getPercentFailureByClassBySex($annee) {
        // Not yet implemented
    }

    /**
     * retourne un array contenant les meilleurs classes par niveau.
     * Par exemple, la meilleur 6e, la meilleur 5e, ..., la meilleur Tle
     * @access public
     */
    public function getBestClassByLevel() {
        // Not yet implemented
    }

    /**
     * @access public
     */
    public function getWorstClassByLevel() {
        // Not yet implemented
    }

    /**
     * @access public
     */
    public function getBestClassByLevelBySerie() {
        // Not yet implemented
    }

    /**
     * @access public
     */
    public function getWorstClassByLevelBySerie() {
        // Not yet implemented
    }

    /**
     * @access public
     */
    public function getPercentSucessByClassBySerie() {
        // Not yet implemented
    }

    /**
     * @access public
     */
    public function getPercentFailureByClassBySerie() {
        // Not yet implemented
    }

    /**
     * @access public
     * @param int annee
     * @ParamType annee int
     */
    public function getBestClass($annee) {
        // Not yet implemented
    }

    /**
     * @access public
     * @param int annee
     * @ParamType annee int
     */
    public function getWorstClass($annee) {
        // Not yet implemented
    }

}

