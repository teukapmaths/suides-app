<?php

require_once(realpath(dirname(__FILE__)) . '/../../suides/gestion/enseignant.php');
require_once(realpath(dirname(__FILE__)) . '/../../suides/gestion/classe.php');
require_once(realpath(dirname(__FILE__)) . '/../../suides/gestion/matiere.php');

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class Programme {

    /**
     * @AssociationType core.enseignant
     * @AssociationMultiplicity 1..*
     */
    public $enseignant = array();

    /**
     * @AssociationType core.classe
     * @AssociationMultiplicity 1..*
     */
    public $classe = array();

    /**
     * @AssociationType core.matiere
     * @AssociationMultiplicity 1..*
     */
    public $matiere = array();

    public $annee;

}

?>