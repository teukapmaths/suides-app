<?php

/**
 * @access public
 * @author teukapmaths
 * @package suides.gestion
 */
class Tranche {

    /**
     * @AttributeType int
     */
    private $numoperation;

    /**
     * @AttributeType int
     */
    private $annee;

    /**
     * @AttributeType int
     */
    private $montant;

    /**
     * @AttributeType String
     */
    private $datepaiement;

    function getNumoperation() {
        return $this->numoperation;
    }

    function getAnnee() {
        return $this->annee;
    }

    function getMontant() {
        return $this->montant;
    }

    function getDatepaiement() {
        return $this->datepaiement;
    }

    function setNumoperation($numoperation) {
        $this->numoperation = $numoperation;
    }

    function setAnnee($annee) {
        $this->annee = $annee;
    }

    function setMontant($montant) {
        $this->montant = $montant;
    }

    function setDatepaiement($datepaiement) {
        $this->datepaiement = $datepaiement;
    }


}

?>