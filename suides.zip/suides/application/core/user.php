<?php

require_once(realpath(dirname(__FILE__)) . '/../../suides/gestion/person.php');

/**
 * @access public
 * @author teukapmaths
 * @package core
 */
class User extends Person {

    /**
     * @AttributeType String
     */
    private $login;

    /**
     * @AttributeType String
     */
    private $passwd;

    /**
     * @AttributeType String
     */
    private $description;

    /**
     * @AttributeType String
     */
    private $codeetatblissement;

    /**
     * @AttributeType String
     */
    private $role;

    /**
     * @access public
     */
    public function getMyPrivileges() {
        // Not yet implemented
    }

    /**
     * @access public
     * @return boolean
     * @ReturnType boolean
     */
    public function seConnecter() {
        // Not yet implemented
    }

    function getLogin() {
        return $this->login;
    }

    function getPasswd() {
        return $this->passwd;
    }

    function getDescription() {
        return $this->description;
    }

    function getCodeetatblissement() {
        return $this->codeetatblissement;
    }

    function getRole() {
        return $this->role;
    }

    function setLogin($login) {
        $this->login = $login;
    }

    function setPasswd($passwd) {
        $this->passwd = $passwd;
    }

    function setDescription($description) {
        $this->description = $description;
    }

    function setCodeetatblissement($codeetatblissement) {
        $this->codeetatblissement = $codeetatblissement;
    }

    function setRole($role) {
        $this->role = $role;
    }


}

?>