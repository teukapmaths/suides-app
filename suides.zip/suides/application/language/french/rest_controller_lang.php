<?php

/*
 * French language
 */


$lang['text_rest_invalid_api_key'] = 'clé API valide% s'; //% S est la clé API REST
$lang['text_rest_invalid_credentials'] = 'Invalid credentials';
$lang['text_rest_ip_denied'] = 'IP refusé';
$lang['text_rest_ip_unauthorized'] = 'IP non autorisée';
$lang['text_rest_unauthorized'] = 'non autorisée';
$lang['text_rest_ajax_only'] = 'Seuls les requêtes AJAX sont permis';
$lang['text_rest_api_key_unauthorized'] = "Cette clé API n'a pas accès à la commande demandée";
$lang['text_rest_api_key_permissions'] = "Cette clé API ne possède pas suffisamment d'autorisations";
$lang['text_rest_api_key_time_limit'] = 'Cette clé API a atteint la limite de temps pour cette méthode';
$lang['text_rest_unknown_method'] = 'méthode inconnue';
$lang['text_rest_unsupported'] = 'protocole non pris en charge';

